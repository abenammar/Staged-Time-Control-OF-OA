# Third-party data sources and licenses

1) ToeInKAMReduction (X_TIdiff.csv, y_TIP1diff.csv)
   Source: https://github.com/suhlrich/ToeInKAMReduction
   License: Apache-2.0
   Files are downloaded by the fetch scripts into ./data/
   Copyright remains with original authors.

2) Multivariate Gait Data (gait.csv)
   Source: UCI Machine Learning Repository (Dataset ID 760)
   DOI: 10.24432/C5861T
   License: CC BY 4.0 (Credit: Helwig, N. & Hsiao-Wecksler, E.)
